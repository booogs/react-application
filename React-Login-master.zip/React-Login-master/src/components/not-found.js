import React from 'react'

module.exports = React.createClass({
  render: function() {
    return (
      <div>
        <h1>PAGE NOT FOUND</h1>
      </div>
    )
  }
})
